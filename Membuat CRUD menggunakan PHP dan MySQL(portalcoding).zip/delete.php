<?php
include "konektor.php";
$noktp = $_GET['noktp'];
$SQL = $con -> prepare("DELETE FROM volunter WHERE noktp=?");
$SQL -> bind_param("s",$noktp);
$SQL -> execute();

if($SQL) {
		echo "
			<script type='text/javascript'>
				alert('Delete Data Berhasil !!!');
			</script>
		";
		echo "
			<script type='text/javascript'>
				window.location ='index.php';
			</script>
		";
	} else {
		echo "
			<script type='text/javascript'>
				alert('Delete Data Gagal !!!');
			</script>
		";
	}


?>