<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "lks2";

$con = new mysqli($host,$user,$pass,$db) or die ("tidak bisa koneksi ke database");
?>