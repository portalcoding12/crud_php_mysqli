<?php
include "konektor.php";
?>
<html>
<head>
	<title>Formulir Pendaftaran Volunteer Asian Games 2018</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<head>
<body>

<div class="layout">
	<div class="background">
		
		<h2>Formulir Pendaftaran Volunteer Asian Games 2018</h2>
		<div class="setback">
		<a href="index.php" class="back"><b><= </b></a>
		</div>
		<div class="form">
			<form method="post" action="">
		<div>
			<label for="noktp" class="label">Nomor KTP
			</label>
				<input type="text" class="form-input" placeholder="Nomor KTP" name="noktp">
		</div>

		<div>
		<label for="nama" class="label">Nama
		</label>
			<input type="text" class="form-input" placeholder="Nama Anda" name="nama">
		</div>
		
		<div>
		<label for="radiobtn" class="label">Jenis Kelamin
			<input type="radio" class="radiobtn" value="Laki-laki" name="jk">Laki-laki
			<input type="radio" class="radiobtn-pr" value="Perempuan" name="jk">Perempuan
		</label>
		</div>
		
		<div>
		<label for="alamat" class="label"> Alamat
		</label>
			<textarea class="textarea form-input "  name="alamat"></textarea>
		</div>
		
		<div>
		<label for="cabor" class="label"> Cabang Olahraga
		</label>
			<select class="form-input" name="cabor">
				<option>Atletik</option>
				<option>Sepak Bola</option>
				<option>Bola Basket</option>
				<option>Taekwondo</option>
				<option>Panahan</option>
			</select>
		</div>
		<div>
			<input type="submit" class="btn-login" value="Simpan" name="simpan">
			</div>
		</form>

		</div>
	</div>
</div>
<div>
		<p class="copyright">Copyright @ 2018. Allright Reserved.</p>
	</div>
</body>
</html>

<?php
if(isset($_POST['simpan'])) {
	$noktp = $_POST['noktp'];
	$nama = $_POST['nama'];
	$jeniskelamin = $_POST['jk'];
	$alamat = $_POST['alamat'];
	$cabor = $_POST['cabor'];
	
	$SQL = $con -> prepare("INSERT INTO volunter(noktp,nama,jeniskelamin,alamat,cabor) VALUES(?,?,?,?,?)");
	$SQL -> bind_param("sssss",$noktp,$nama,$jeniskelamin,$alamat,$cabor);
	$SQL ->execute();
	
	if($SQL) {
		echo "
			<script type='text/javascript'>
				alert('Upload Data Berhasil !!!');
			</script>
		";
		echo "
			<script type='text/javascript'>
				window.location ='index.php';
			</script>
		";
	} else {
		echo "
			<script type='text/javascript'>
				alert('Upload Data Gagal !!!');
			</script>
		";
	}
}
?>