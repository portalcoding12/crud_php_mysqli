<?php
include "konektor.php";
$noktp = $_GET['noktp'];
$SQL = mysqli_query($con,"SELECT * FROM volunter where noktp='$noktp'");
?>
<html>
<head>
	<title>Formulir Pendaftaran Volunteer Asian Games 2018</title>
	<link rel="stylesheet" type="text/css" href="style.css">
<head>
<body>

<div class="layout">
	<div class="background">
		
		<h2>Formulir Pendaftaran Volunteer Asian Games 2018</h2>
		<div class="setback">
		<a href="index.php" class="back"><b><= </b></a>
		</div>
		<div class="form">
			<form method="post" action="">
		<?php while($row = mysqli_fetch_array($SQL)) { ?>
		<div>
			<label for="noktp" class="label">Nomor KTP
			</label>
				<input type="text" class="form-input" value="<?php echo $row['noktp']; ?>" name="noktp">
		</div>

		<div>
		<label for="nama" class="label">Nama
		</label>
			<input type="text" class="form-input" value="<?php echo $row['nama']; ?>" name="nama">
		</div>
		
		<div>
		<label for="radiobtn" class="label">Jenis Kelamin
			<input type="radio" class="radiobtn" value="Laki-laki" name="jk">Laki-laki
			<input type="radio" class="radiobtn-pr" value="Perempuan" name="jk">Perempuan
		</label>
		</div>
		
		<div>
		<label for="alamat" class="label"> Alamat
		</label>
			<textarea class="textarea form-input "  name="alamat"><?php echo $row['alamat']; ?></textarea>
		</div>
		
		<div>
		<label for="cabor" class="label"> Cabang Olahraga
		</label>
			<select class="form-input" name="cabor">
				<option><?php echo $row['cabor']; ?></option>
				<option>Atletik</option>
				<option>Sepak Bola</option>
				<option>Bola Basket</option>
				<option>Taekwondo</option>
				<option>Panahan</option>
			</select>
		</div>
		<?php } ?>
		<div>
			<input type="submit" class="btn-login" value="Simpan" name="simpan">
			</div>
		</form>

		</div>
	</div>
</div>
<div>
		<p class="copyright">Copyright @ 2018. Allright Reserved.</p>
	</div>
</body>
</html>
<?php
if(isset($_POST['simpan'])) {
	$noktp = $_POST['noktp'];
	$nama = $_POST['nama'];
	$jeniskelamin = $_POST['jk'];
	$alamat = $_POST['alamat'];
	$cabor = $_POST['cabor'];
	
	$SQL = $con -> prepare("UPDATE volunter SET nama=?, jeniskelamin=?, alamat=?, cabor=? WHERE noktp=? ");
	$SQL -> bind_param("sssss",$nama,$jeniskelamin,$alamat,$cabor,$noktp);
	$SQL -> execute();
	
	if($SQL) {
		echo "
			<script type='text/javascript'>
				alert('Update Data Berhasil !!!');
			</script>
		";
		echo "
			<script type='text/javascript'>
				window.location ='index.php';
			</script>
		";
	} else {
		echo "
			<script type='text/javascript'>
				alert('Update Data Gagal !!!');
			</script>
		";
	}
}
?>
