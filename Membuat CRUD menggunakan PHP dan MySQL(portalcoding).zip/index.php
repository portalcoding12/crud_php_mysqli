<?php
include "konektor.php";
$SQL = mysqli_query($con,"SELECT * FROM volunter");
$nomor = 1;
?>
<html>
<head>
<title>Formulir Pendaftaran Volunteer Asian Games 2018</title>
	<link rel="stylesheet" type="text/css" href="style-home.css">
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript">
		
	</script>
</head>
<body>
	<div class="">
	<div class="header">
		<div><img src="profile/header.png" class="logo"></div>
		<p class="txtHeader">Administrator</p>
		</div>
		<div><input type="submit" id="btnProfile" class="btnProfile" value="Administrator">
		</div>
		<div></div>
	</div>
	<div class="navbar">
	<ul>
		<div><img class="logoProfile" src="profile/user-lk.png"></div>
		<li>
		<form method="post" action="">
		<input type="button" id="btn1" class="active btn btn1" value="Data Volunteer"></li>
		</form>
	</div>
	<div class="contentarea">
	<div id="bg"></div>
	<div id="data-user">
		<h1>Data Volunteer</h1>
		<div><a href="add.php" class="btnTambah" name="tambahVol" > + Tambah Data</a></div>
		<div class="bdBottom"></div>
		<table cellpadding="8">
		<th>Nomor</th>
		<th>Nomor KTP</th>
		<th>Nama</th>
		<th>Jenis Kelamin</th>
		<th>Alamat</th>
		<th>Cabang Olahraga</th>
		<th>Opsi</th>
		
		<?php while($row = mysqli_fetch_array($SQL)) { ?>
		<tr>
			<td><?php echo $nomor++ ?></td>
			<td><?php echo $row['noktp']; ?></td>
			<td><?php echo $row['nama']; ?></td>
			<td><?php echo $row['jeniskelamin']; ?></td>
			<td><?php echo $row['alamat']; ?></td>
			<td><?php echo $row['cabor']; ?></td>
			<td><a href="edit.php?noktp=<?php echo $row['noktp']; ?>" class="btnEdit">Edit</a> | <a href="delete.php?noktp=<?php echo $row['noktp']; ?>" class="btnDel">Hapus</a></td>
		</tr>
		<?php }?>
		</table>
	</div>

	</div>
	<div class="footer">
		<div><p class="copyright">CopyRight &copy 2018. All Right Reserved.</p></div>
	</div>
</body>
</html>

<?php
if(isset($_POST['tambahVol'])) {
	header("location:https://www.kodeajaib.com");
}

?>